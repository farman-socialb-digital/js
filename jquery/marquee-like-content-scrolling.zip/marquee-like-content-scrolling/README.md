# Marquee-like Content Scrolling

A Pen created on CodePen.io. Original URL: [https://codepen.io/Coding_Journey/pen/yWjWKd](https://codepen.io/Coding_Journey/pen/yWjWKd).

Scrolling Content (Marquee Effect)