# jQuery 8.51 Swiper

A Pen created on CodePen.io. Original URL: [https://codepen.io/chiaya710623/pen/pYjeya](https://codepen.io/chiaya710623/pen/pYjeya).

